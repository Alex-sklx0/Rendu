import crypto from 'node:crypto';
import { supabase } from '../config/supabaseClient.js';

const BUCKET = 'Imagenes';

/**
 * Extrae la ruta relativa dentro del bucket (ej. "subproductos/uuid.jpg")
 * a partir de una URL pública de Supabase Storage.
 */
function extractStoragePath(url) {
  if (!url || typeof url !== 'string') return null;
  const marker = `/${BUCKET}/`;
  if (!url.includes(marker)) return null;
  const parts = url.split(marker);
  if (!parts[1]) return null;
  return decodeURIComponent(parts[1].split('?')[0]);
}

/**
 * Elimina un archivo de Supabase Storage a partir de su URL pública.
 * No lanza error si falla — solo lo registra (borrar la imagen vieja
 * nunca debe tumbar la operación principal, como actualizar el subproducto).
 */
export async function deleteStorageFile(url) {
  const path = extractStoragePath(url);
  if (!path) return;

  const { error } = await supabase.storage.from(BUCKET).remove([path]);
  if (error) {
    console.warn(`[StorageService] No se pudo eliminar '${path}':`, error.message);
  }
}

/**
 * Sube una imagen (Base64 / Data